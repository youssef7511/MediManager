package com.example.medimanager.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.models.Consultation;

import java.util.List;

public class ConsultationAdapter extends RecyclerView.Adapter<ConsultationAdapter.ConsultationViewHolder> {

    private Context context;
    private List<Consultation> consultationList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Consultation consultation);
        void onEditClick(Consultation consultation);
        void onDeleteClick(Consultation consultation);
    }

    public ConsultationAdapter(Context context, List<Consultation> consultationList) {
        this.context = context;
        this.consultationList = consultationList;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ConsultationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_consultation, parent, false);
        return new ConsultationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ConsultationViewHolder holder, int position) {
        Consultation consultation = consultationList.get(position);

        // Format and set consultation date
        String formattedDate = DateUtils.formatDate(consultation.getConsultationDate());
        holder.tvDate.setText(formattedDate);

        // Set diagnosis
        String diagnosis = consultation.getDiagnosis();
        if (diagnosis != null && !diagnosis.isEmpty()) {
            holder.tvDiagnosis.setText(diagnosis);
        } else {
            holder.tvDiagnosis.setText("No diagnosis");
        }

        // Set treatment
        String treatment = consultation.getTreatment();
        if (treatment != null && !treatment.isEmpty()) {
            holder.tvTreatment.setText(treatment);
        } else {
            holder.tvTreatment.setText("No treatment specified");
        }

        // Set time ago
        String timeAgo = DateUtils.getTimeAgo(consultation.getConsultationDate());
        holder.tvTimeAgo.setText(timeAgo);

        // Click listeners
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(consultation);
                }
            }
        });

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onEditClick(consultation);
                }
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onDeleteClick(consultation);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return consultationList != null ? consultationList.size() : 0;
    }

    public void updateList(List<Consultation> newList) {
        this.consultationList = newList;
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        consultationList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, consultationList.size());
    }

    public static class ConsultationViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvDiagnosis, tvTreatment, tvTimeAgo;
        ImageButton btnEdit, btnDelete;

        public ConsultationViewHolder(@NonNull View itemView) {
            super(itemView);

            tvDate = itemView.findViewById(R.id.tvDate);
            tvDiagnosis = itemView.findViewById(R.id.tvDiagnosis);
            tvTreatment = itemView.findViewById(R.id.tvTreatment);
            tvTimeAgo = itemView.findViewById(R.id.tvTimeAgo);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}