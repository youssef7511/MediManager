package com.example.medimanager.activities;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medimanager.R;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Patient;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddPatientActivity extends AppCompatActivity {

    // UI Components
    private TextView tvTitle;
    private ImageButton btnBack;
    private TextInputEditText etFirstName, etLastName, etDateOfBirth;
    private TextInputEditText etPhone, etEmail, etAddress, etAllergies;
    private AutoCompleteTextView spinnerGender, spinnerBloodGroup;
    private Button btnCancel, btnSave;

    // Data
    private PatientDAO patientDAO;
    private Patient currentPatient;
    private boolean isEditMode = false;
    private Calendar selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        // Initialize DAO
        patientDAO = new PatientDAO(this);

        // Check if editing existing patient
        checkEditMode();

        // Initialize UI
        initializeViews();
        setupSpinners();
        setupClickListeners();

        // Load patient data if editing
        if (isEditMode && currentPatient != null) {
            loadPatientData();
        }
    }

    private void checkEditMode() {
        if (getIntent().hasExtra("PATIENT_ID")) {
            isEditMode = true;
            int patientId = getIntent().getIntExtra("PATIENT_ID", -1);

            try {
                patientDAO.open();
                currentPatient = patientDAO.getPatientById(patientId);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Error loading patient", Toast.LENGTH_SHORT).show();
                finish();
            } finally {
                patientDAO.close();
            }
        }
    }

    private void initializeViews() {
        // Header
        tvTitle = findViewById(R.id.tvTitle);
        btnBack = findViewById(R.id.btnBack);

        // Input fields
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etDateOfBirth = findViewById(R.id.etDateOfBirth);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        etAddress = findViewById(R.id.etAddress);
        etAllergies = findViewById(R.id.etAllergies);

        // Spinners
        spinnerGender = findViewById(R.id.spinnerGender);
        spinnerBloodGroup = findViewById(R.id.spinnerBloodGroup);

        // Buttons
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        // Update title based on mode
        if (isEditMode) {
            tvTitle.setText(R.string.edit_patient_info);
        }
    }

    private void setupSpinners() {
        // Gender Spinner
        String[] genders = getResources().getStringArray(R.array.genders);
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                genders
        );
        spinnerGender.setAdapter(genderAdapter);

        // Blood Group Spinner
        String[] bloodGroups = getResources().getStringArray(R.array.blood_groups);
        ArrayAdapter<String> bloodGroupAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                bloodGroups
        );
        spinnerBloodGroup.setAdapter(bloodGroupAdapter);
    }

    private void setupClickListeners() {
        // Back button
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Date picker
        etDateOfBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        // Cancel button
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Save button
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    savePatient();
                }
            }
        });
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();

        // If editing and date exists, use it
        if (isEditMode && currentPatient != null && currentPatient.getDateOfBirth() != null) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                calendar.setTime(sdf.parse(currentPatient.getDateOfBirth()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        selectedDate = Calendar.getInstance();
                        selectedDate.set(year, month, dayOfMonth);

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                        String dateString = sdf.format(selectedDate.getTime());
                        etDateOfBirth.setText(dateString);
                    }
                },
                year, month, day
        );

        // Set max date to today
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private boolean validateInputs() {
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        // Validate first name
        if (firstName.isEmpty()) {
            etFirstName.setError(getString(R.string.required_field));
            etFirstName.requestFocus();
            return false;
        }

        // Validate last name
        if (lastName.isEmpty()) {
            etLastName.setError(getString(R.string.required_field));
            etLastName.requestFocus();
            return false;
        }

        // Validate phone (optional but check format if provided)
        if (!phone.isEmpty() && phone.length() < 10) {
            etPhone.setError(getString(R.string.invalid_phone));
            etPhone.requestFocus();
            return false;
        }

        // Validate email (optional but check format if provided)
        if (!email.isEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError(getString(R.string.invalid_email));
            etEmail.requestFocus();
            return false;
        }

        return true;
    }

    private void savePatient() {
        try {
            // Get current date for lastVisit if new patient
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdf.format(Calendar.getInstance().getTime());

            // Create or update patient object
            if (currentPatient == null) {
                currentPatient = new Patient();
            }

            currentPatient.setFirstName(etFirstName.getText().toString().trim());
            currentPatient.setLastName(etLastName.getText().toString().trim());
            currentPatient.setDateOfBirth(etDateOfBirth.getText().toString().trim());
            currentPatient.setGender(spinnerGender.getText().toString());
            currentPatient.setPhone(etPhone.getText().toString().trim());
            currentPatient.setEmail(etEmail.getText().toString().trim());
            currentPatient.setAddress(etAddress.getText().toString().trim());
            currentPatient.setBloodGroup(spinnerBloodGroup.getText().toString());
            currentPatient.setAllergies(etAllergies.getText().toString().trim());

            patientDAO.open();

            if (isEditMode) {
                // Update existing patient
                int result = patientDAO.updatePatient(currentPatient);
                if (result > 0) {
                    Toast.makeText(this, R.string.patient_updated, Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            } else {
                // Insert new patient
                currentPatient.setLastVisit(currentDate);
                long id = patientDAO.insertPatient(currentPatient);

                if (id > 0) {
                    Toast.makeText(this, R.string.patient_added, Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
        }
    }

    private void loadPatientData() {
        if (currentPatient == null) return;

        etFirstName.setText(currentPatient.getFirstName());
        etLastName.setText(currentPatient.getLastName());
        etDateOfBirth.setText(currentPatient.getDateOfBirth());
        spinnerGender.setText(currentPatient.getGender(), false);
        etPhone.setText(currentPatient.getPhone());
        etEmail.setText(currentPatient.getEmail());
        etAddress.setText(currentPatient.getAddress());
        spinnerBloodGroup.setText(currentPatient.getBloodGroup(), false);
        etAllergies.setText(currentPatient.getAllergies());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (patientDAO != null) {
            patientDAO.close();
        }
    }
}
