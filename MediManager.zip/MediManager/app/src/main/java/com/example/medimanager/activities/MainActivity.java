package com.example.medimanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.adapters.AppointmentAdapter;
import com.example.medimanager.database.AppointmentDAO;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Appointment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // UI Components
    private TextView tvTodayAppointments, tvTotalPatients, tvPendingTasks, tvWeeklyVisits;
    private TextView tvDate, tvViewAll;
    private RecyclerView rvTodayAppointments;
    private Button btnNewAppointment, btnAddPatient;
    private FloatingActionButton fabAddPatient;
    private BottomNavigationView bottomNavigation;

    // Database
    private PatientDAO patientDAO;
    private AppointmentDAO appointmentDAO;

    // Adapters
    private AppointmentAdapter appointmentAdapter;
    private List<Appointment> todayAppointments;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize DAOs
        patientDAO = new PatientDAO(this);
        appointmentDAO = new AppointmentDAO(this);

        // Initialize UI
        initializeViews();
        setupRecyclerView();
        setupClickListeners();
        setupBottomNavigation();

        // Load data
        loadStatistics();
        loadTodayAppointments();
        updateDate();
    }

    private void initializeViews() {
        // Statistics TextViews
        tvTodayAppointments = findViewById(R.id.tvTodayAppointments);
        tvTotalPatients = findViewById(R.id.tvTotalPatients);
        tvPendingTasks = findViewById(R.id.tvPendingTasks);
        tvWeeklyVisits = findViewById(R.id.tvWeeklyVisits);

        // Other TextViews
        tvDate = findViewById(R.id.tvDate);
        tvViewAll = findViewById(R.id.tvViewAll);

        // RecyclerView
        rvTodayAppointments = findViewById(R.id.rvTodayAppointments);

        // Buttons
        btnNewAppointment = findViewById(R.id.btnNewAppointment);
        btnAddPatient = findViewById(R.id.btnAddPatient);
        fabAddPatient = findViewById(R.id.fabAddPatient);

        // Bottom Navigation
        bottomNavigation = findViewById(R.id.bottomNavigation);
    }

    private void setupRecyclerView() {
        todayAppointments = new ArrayList<>();
        appointmentAdapter = new AppointmentAdapter(this, todayAppointments);

        rvTodayAppointments.setLayoutManager(new LinearLayoutManager(this));
        rvTodayAppointments.setAdapter(appointmentAdapter);
        rvTodayAppointments.setNestedScrollingEnabled(false);

        // Set item click listener
        appointmentAdapter.setOnItemClickListener(new AppointmentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Appointment appointment) {
                // Navigate to appointment details or patient details
                Intent intent = new Intent(MainActivity.this, PatientDetailsActivity.class);
                intent.putExtra("PATIENT_ID", appointment.getPatientId());
                startActivity(intent);
            }

            @Override
            public void onStatusClick(Appointment appointment) {
                // Update appointment status
                updateAppointmentStatus(appointment);
            }
        });
    }

    private void setupClickListeners() {
        // View All button
        tvViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to full appointments list
                Intent intent = new Intent(MainActivity.this, AppointmentsActivity.class);
                startActivity(intent);
            }
        });

        // New Appointment button
        btnNewAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to add appointment screen
                Toast.makeText(MainActivity.this, "Add Appointment", Toast.LENGTH_SHORT).show();
                // Intent intent = new Intent(MainActivity.this, AddAppointmentActivity.class);
                // startActivity(intent);
            }
        });

        // Add Patient button
        btnAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAddPatient();
            }
        });

        // FAB Add Patient
        fabAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToAddPatient();
            }
        });
    }

    private void setupBottomNavigation() {
        bottomNavigation.setSelectedItemId(R.id.nav_home);

        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    // Already on home
                    return true;
                } else if (itemId == R.id.nav_appointments) {
                    startActivity(new Intent(MainActivity.this, AppointmentsActivity.class));
                    return true;
                } else if (itemId == R.id.nav_patients) {
                    startActivity(new Intent(MainActivity.this, PatientsActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    Toast.makeText(MainActivity.this, "Profile", Toast.LENGTH_SHORT).show();
                    return true;
                }

                return false;
            }
        });
    }

    private void loadStatistics() {
        try {
            patientDAO.open();
            appointmentDAO.open();

            // Get today's date
            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            // Load statistics
            int totalPatients = patientDAO.getTotalPatientsCount();
            int todayAppointmentsCount = appointmentDAO.getTodayAppointmentsCount(today);
            int upcomingAppointments = appointmentDAO.getUpcomingAppointmentsCount();

            // Update UI
            tvTotalPatients.setText(String.valueOf(totalPatients));
            tvTodayAppointments.setText(String.valueOf(todayAppointmentsCount));
            tvPendingTasks.setText(String.valueOf(upcomingAppointments));
            tvWeeklyVisits.setText("42"); // Mock data for now

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading statistics", Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
            appointmentDAO.close();
        }
    }

    private void loadTodayAppointments() {
        try {
            appointmentDAO.open();

            String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            List<Appointment> appointments = appointmentDAO.getTodayAppointments(today);

            todayAppointments.clear();
            todayAppointments.addAll(appointments);
            appointmentAdapter.notifyDataSetChanged();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading appointments", Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    private void updateAppointmentStatus(Appointment appointment) {
        try {
            appointmentDAO.open();

            String newStatus;
            if (appointment.isScheduled()) {
                newStatus = "in_progress";
            } else if (appointment.isInProgress()) {
                newStatus = "completed";
            } else {
                newStatus = "scheduled";
            }

            int result = appointmentDAO.updateAppointmentStatus(appointment.getId(), newStatus);

            if (result > 0) {
                appointment.setStatus(newStatus);
                appointmentAdapter.notifyDataSetChanged();
                Toast.makeText(this, "Status updated", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error updating status", Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    private void updateDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault());
        String currentDate = sdf.format(new Date());
        tvDate.setText(currentDate);
    }

    private void navigateToAddPatient() {
        Intent intent = new Intent(MainActivity.this, AddPatientActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to this activity
        loadStatistics();
        loadTodayAppointments();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (patientDAO != null) {
            patientDAO.close();
        }
        if (appointmentDAO != null) {
            appointmentDAO.close();
        }
    }
}