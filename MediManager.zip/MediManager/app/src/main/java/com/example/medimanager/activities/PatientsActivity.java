package com.example.medimanager.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.adapters.PatientAdapter;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Patient;
import com.example.medimanager.utils.Constants;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class PatientsActivity extends AppCompatActivity {

    // UI Components
    private TextInputEditText etSearch;
    private RecyclerView rvPatients;
    private TextView tvEmptyState, tvTotalPatients;
    private FloatingActionButton fabAddPatient;

    // Data
    private PatientDAO patientDAO;
    private PatientAdapter patientAdapter;
    private List<Patient> patientList;
    private List<Patient> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patients);

        // Initialize DAO
        patientDAO = new PatientDAO(this);

        // Initialize UI
        initializeViews();
        setupRecyclerView();
        setupSearchView();
        setupClickListeners();

        // Load data
        loadPatients();
    }

    private void initializeViews() {
        etSearch = findViewById(R.id.etSearch);
        rvPatients = findViewById(R.id.rvPatients);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        tvTotalPatients = findViewById(R.id.tvTotalPatients);
        fabAddPatient = findViewById(R.id.fabAddPatient);
    }

    private void setupRecyclerView() {
        patientList = new ArrayList<>();
        filteredList = new ArrayList<>();

        patientAdapter = new PatientAdapter(this, filteredList);
        rvPatients.setLayoutManager(new LinearLayoutManager(this));
        rvPatients.setAdapter(patientAdapter);

        // Set click listeners
        patientAdapter.setOnItemClickListener(new PatientAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Patient patient) {
                // Open patient details
                Intent intent = new Intent(PatientsActivity.this, PatientDetailsActivity.class);
                intent.putExtra(Constants.EXTRA_PATIENT_ID, patient.getId());
                startActivity(intent);
            }

            @Override
            public void onEditClick(Patient patient) {
                // Open edit patient
                Intent intent = new Intent(PatientsActivity.this, AddPatientActivity.class);
                intent.putExtra(Constants.EXTRA_PATIENT_ID, patient.getId());
                intent.putExtra(Constants.EXTRA_IS_EDIT_MODE, true);
                startActivityForResult(intent, Constants.REQUEST_EDIT_PATIENT);
            }

            @Override
            public void onDeleteClick(Patient patient) {
                showDeleteConfirmationDialog(patient);
            }
        });
    }

    private void setupSearchView() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterPatients(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void setupClickListeners() {
        fabAddPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientsActivity.this, AddPatientActivity.class);
                startActivityForResult(intent, Constants.REQUEST_ADD_PATIENT);
            }
        });
    }

    private void loadPatients() {
        try {
            patientDAO.open();
            patientList = patientDAO.getAllPatients();
            filteredList.clear();
            filteredList.addAll(patientList);

            patientAdapter.notifyDataSetChanged();
            updateUI();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading patients", Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
        }
    }

    private void filterPatients(String query) {
        filteredList.clear();

        if (query.isEmpty()) {
            // Show all patients
            filteredList.addAll(patientList);
        } else {
            // Filter by name
            String lowerCaseQuery = query.toLowerCase();
            for (Patient patient : patientList) {
                String fullName = patient.getFullName().toLowerCase();
                if (fullName.contains(lowerCaseQuery)) {
                    filteredList.add(patient);
                }
            }
        }

        patientAdapter.notifyDataSetChanged();
        updateUI();
    }

    private void updateUI() {
        // Update total count
        tvTotalPatients.setText(filteredList.size() + " Total");

        // Show/hide empty state
        if (filteredList.isEmpty()) {
            rvPatients.setVisibility(View.GONE);
            tvEmptyState.setVisibility(View.VISIBLE);

            String searchQuery = etSearch.getText().toString().trim();
            if (searchQuery.isEmpty()) {
                tvEmptyState.setText(R.string.no_patients_found);
            } else {
                tvEmptyState.setText("No patients found for \"" + searchQuery + "\"");
            }
        } else {
            rvPatients.setVisibility(View.VISIBLE);
            tvEmptyState.setVisibility(View.GONE);
        }
    }

    private void showDeleteConfirmationDialog(final Patient patient) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirmation)
                .setMessage(R.string.delete_patient_message)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deletePatient(patient);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deletePatient(Patient patient) {
        try {
            patientDAO.open();
            int result = patientDAO.deletePatient(patient.getId());

            if (result > 0) {
                Toast.makeText(this, R.string.patient_deleted, Toast.LENGTH_SHORT).show();

                // Remove from lists
                patientList.remove(patient);
                filteredList.remove(patient);

                patientAdapter.notifyDataSetChanged();
                updateUI();
            } else {
                Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Reload patients after add/edit
            loadPatients();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh data when returning to this activity
        loadPatients();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (patientDAO != null) {
            patientDAO.close();
        }
    }
}
