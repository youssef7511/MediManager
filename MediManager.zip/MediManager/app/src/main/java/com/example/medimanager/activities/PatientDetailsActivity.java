package com.example.medimanager.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.adapters.AppointmentAdapter;
import com.example.medimanager.adapters.ConsultationAdapter;
import com.example.medimanager.database.AppointmentDAO;
import com.example.medimanager.database.ConsultationDAO;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Appointment;
import com.example.medimanager.models.Consultation;
import com.example.medimanager.models.Patient;
import com.example.medimanager.utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class PatientDetailsActivity extends AppCompatActivity {

    // UI Components
    private ImageButton btnBack, btnEdit, btnDelete;
    private TextView tvPatientName, tvAge, tvGender, tvBloodGroup;
    private TextView tvPhone, tvEmail, tvLastVisit;
    private Button btnBookAppointment, btnAddConsultation;
    private RecyclerView rvConsultations, rvAppointments;

    // Data
    private Patient patient;
    private PatientDAO patientDAO;
    private ConsultationDAO consultationDAO;
    private AppointmentDAO appointmentDAO;

    // Adapters
    private ConsultationAdapter consultationAdapter;
    private AppointmentAdapter appointmentAdapter;
    private List<Consultation> consultations;
    private List<Appointment> appointments;

    private int patientId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);

        // Get patient ID from intent
        patientId = getIntent().getIntExtra(Constants.EXTRA_PATIENT_ID, -1);
        if (patientId == -1) {
            Toast.makeText(this, "Error: Patient not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize DAOs
        patientDAO = new PatientDAO(this);
        consultationDAO = new ConsultationDAO(this);
        appointmentDAO = new AppointmentDAO(this);

        // Initialize UI
        initializeViews();
        setupClickListeners();
        setupRecyclerViews();

        // Load data
        loadPatientData();
        loadConsultations();
        loadAppointments();
    }

    private void initializeViews() {
        // Header buttons
        btnBack = findViewById(R.id.btnBack);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        // Patient info
        tvPatientName = findViewById(R.id.tvPatientName);
        tvAge = findViewById(R.id.tvAge);
        tvGender = findViewById(R.id.tvGender);
        tvBloodGroup = findViewById(R.id.tvBloodGroup);
        tvPhone = findViewById(R.id.tvPhone);
        tvEmail = findViewById(R.id.tvEmail);
        tvLastVisit = findViewById(R.id.tvLastVisit);

        // Action buttons
        btnBookAppointment = findViewById(R.id.btnBookAppointment);
        btnAddConsultation = findViewById(R.id.btnAddConsultation);

        // RecyclerViews
        rvConsultations = findViewById(R.id.rvConsultations);
        rvAppointments = findViewById(R.id.rvAppointments);
    }

    private void setupClickListeners() {
        // Back button
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Edit button
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientDetailsActivity.this, AddPatientActivity.class);
                intent.putExtra(Constants.EXTRA_PATIENT_ID, patientId);
                intent.putExtra(Constants.EXTRA_IS_EDIT_MODE, true);
                startActivityForResult(intent, Constants.REQUEST_EDIT_PATIENT);
            }
        });

        // Delete button - FONCTION DELETE COMPLÈTE
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteConfirmationDialog();
            }
        });

        // Book appointment
        btnBookAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PatientDetailsActivity.this, "Book appointment feature coming soon", Toast.LENGTH_SHORT).show();
            }
        });

        // Add consultation
        btnAddConsultation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientDetailsActivity.this, AddConsultationActivity.class);
                intent.putExtra(Constants.EXTRA_PATIENT_ID, patientId);
                startActivityForResult(intent, Constants.REQUEST_ADD_CONSULTATION);
            }
        });
    }

    private void setupRecyclerViews() {
        // Consultations RecyclerView
        consultations = new ArrayList<>();
        consultationAdapter = new ConsultationAdapter(this, consultations);
        rvConsultations.setLayoutManager(new LinearLayoutManager(this));
        rvConsultations.setAdapter(consultationAdapter);
        rvConsultations.setNestedScrollingEnabled(false);

        consultationAdapter.setOnItemClickListener(new ConsultationAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Consultation consultation) {
                // View consultation details
                Toast.makeText(PatientDetailsActivity.this, "View consultation", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onEditClick(Consultation consultation) {
                // Edit consultation
                Intent intent = new Intent(PatientDetailsActivity.this, AddConsultationActivity.class);
                intent.putExtra(Constants.EXTRA_CONSULTATION_ID, consultation.getId());
                intent.putExtra(Constants.EXTRA_PATIENT_ID, patientId);
                intent.putExtra(Constants.EXTRA_IS_EDIT_MODE, true);
                startActivityForResult(intent, Constants.REQUEST_ADD_CONSULTATION);
            }

            @Override
            public void onDeleteClick(Consultation consultation) {
                showDeleteConsultationDialog(consultation);
            }
        });

        // Appointments RecyclerView
        appointments = new ArrayList<>();
        appointmentAdapter = new AppointmentAdapter(this, appointments);
        rvAppointments.setLayoutManager(new LinearLayoutManager(this));
        rvAppointments.setAdapter(appointmentAdapter);
        rvAppointments.setNestedScrollingEnabled(false);
    }

    private void loadPatientData() {
        try {
            patientDAO.open();
            patient = patientDAO.getPatientById(patientId);

            if (patient != null) {
                // Set patient info
                tvPatientName.setText(patient.getFullName());
                tvAge.setText(patient.getAge() + " years old");
                tvGender.setText(patient.getGender() != null ? patient.getGender() : "N/A");
                tvBloodGroup.setText("Blood: " + (patient.getBloodGroup() != null ? patient.getBloodGroup() : "N/A"));
                tvPhone.setText(patient.getPhone() != null ? patient.getPhone() : "No phone");
                tvEmail.setText(patient.getEmail() != null ? patient.getEmail() : "No email");
                tvLastVisit.setText("Last visit: " + (patient.getLastVisit() != null ? patient.getLastVisit() : "Never"));
            } else {
                Toast.makeText(this, "Patient not found", Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading patient data", Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
        }
    }

    private void loadConsultations() {
        try {
            consultationDAO.open();
            List<Consultation> loadedConsultations = consultationDAO.getConsultationsByPatient(patientId);
            consultations.clear();
            consultations.addAll(loadedConsultations);
            consultationAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            consultationDAO.close();
        }
    }

    private void loadAppointments() {
        try {
            appointmentDAO.open();
            List<Appointment> loadedAppointments = appointmentDAO.getAppointmentsByPatient(patientId);
            appointments.clear();
            appointments.addAll(loadedAppointments);
            appointmentAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            appointmentDAO.close();
        }
    }

    // FONCTION DELETE PATIENT COMPLÈTE
    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirmation)
                .setMessage(R.string.delete_patient_message)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deletePatient();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deletePatient() {
        try {
            patientDAO.open();
            int result = patientDAO.deletePatient(patientId);

            if (result > 0) {
                Toast.makeText(this, R.string.patient_deleted, Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
        } finally {
            patientDAO.close();
        }
    }

    // DELETE CONSULTATION
    private void showDeleteConsultationDialog(final Consultation consultation) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirmation)
                .setMessage(R.string.delete_consultation_message)
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteConsultation(consultation);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteConsultation(Consultation consultation) {
        try {
            consultationDAO.open();
            // Implement delete in ConsultationDAO
            Toast.makeText(this, "Consultation deleted", Toast.LENGTH_SHORT).show();
            loadConsultations();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error deleting consultation", Toast.LENGTH_SHORT).show();
        } finally {
            consultationDAO.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // Reload data after edit
            loadPatientData();
            loadConsultations();
            loadAppointments();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (patientDAO != null) patientDAO.close();
        if (consultationDAO != null) consultationDAO.close();
        if (appointmentDAO != null) appointmentDAO.close();
    }
}