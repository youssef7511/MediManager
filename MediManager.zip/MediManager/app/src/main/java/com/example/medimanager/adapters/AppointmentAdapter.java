package com.example.medimanager.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.models.Appointment;
import com.example.medimanager.utils.Constants;

import java.util.List;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentAdapter.AppointmentViewHolder> {

    private Context context;
    private List<Appointment> appointmentList;
    private OnItemClickListener listener;

    // Interface for click listeners
    public interface OnItemClickListener {
        void onItemClick(Appointment appointment);
        void onStatusClick(Appointment appointment);
    }

    public AppointmentAdapter(Context context, List<Appointment> appointmentList) {
        this.context = context;
        this.appointmentList = appointmentList;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public AppointmentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_appointment, parent, false);
        return new AppointmentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppointmentViewHolder holder, int position) {
        Appointment appointment = appointmentList.get(position);

        // Set patient name
        if (appointment.getPatientName() != null && !appointment.getPatientName().isEmpty()) {
            holder.tvPatientName.setText(appointment.getPatientName());
        } else {
            holder.tvPatientName.setText("Unknown Patient");
        }

        // Set appointment time
        if (appointment.getAppointmentTime() != null && !appointment.getAppointmentTime().isEmpty()) {
            holder.tvTime.setText(appointment.getAppointmentTime());
        } else {
            holder.tvTime.setText("--:--");
        }

        // Set reason
        if (appointment.getReason() != null && !appointment.getReason().isEmpty()) {
            holder.tvReason.setText(appointment.getReason());
        } else {
            holder.tvReason.setText("No reason specified");
        }

        // Set status with color
        String status = appointment.getStatusDisplayName();
        holder.tvStatus.setText(status);

        // Set status background color and text color based on status
        if (appointment.isCompleted()) {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_status_completed);
            holder.tvStatus.setTextColor(Color.WHITE);
        } else if (appointment.isInProgress()) {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_status_in_progress);
            holder.tvStatus.setTextColor(Color.WHITE);
        } else if (appointment.isCancelled()) {
            holder.tvStatus.setBackgroundResource(R.drawable.bg_status_scheduled);
            holder.tvStatus.setTextColor(Color.WHITE);
        } else {
            // Scheduled (default)
            holder.tvStatus.setBackgroundResource(R.drawable.bg_status_scheduled);
            holder.tvStatus.setTextColor(Color.WHITE);
        }

        // Click listeners
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(appointment);
                }
            }
        });

        holder.tvStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onStatusClick(appointment);
                }
            }
        });

        // Optional: Make the card clickable with ripple effect
        holder.cardView.setClickable(true);
        holder.cardView.setFocusable(true);
    }

    @Override
    public int getItemCount() {
        return appointmentList != null ? appointmentList.size() : 0;
    }

    public void updateList(List<Appointment> newList) {
        this.appointmentList = newList;
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        if (appointmentList != null && position >= 0 && position < appointmentList.size()) {
            appointmentList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, appointmentList.size());
        }
    }

    public static class AppointmentViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView tvPatientName, tvTime, tvReason, tvStatus;

        public AppointmentViewHolder(@NonNull View itemView) {
            super(itemView);

            cardView = (CardView) itemView;
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvReason = itemView.findViewById(R.id.tvReason);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}