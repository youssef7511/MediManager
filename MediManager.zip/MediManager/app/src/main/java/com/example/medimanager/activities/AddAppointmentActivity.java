package com.example.medimanager.activities;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medimanager.AppointmentNotificationReceiver;
import com.example.medimanager.R;
import com.example.medimanager.database.AppointmentDAO;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Appointment;
import com.example.medimanager.models.Patient;
import com.example.medimanager.utils.Constants;
import com.example.medimanager.utils.DateUtils;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AddAppointmentActivity extends AppCompatActivity {

    // UI Components
    private ImageButton btnBack;
    private TextView tvTitle;
    private AutoCompleteTextView spinnerPatient, spinnerStatus;
    private TextInputEditText etAppointmentDate, etAppointmentTime, etReason, etNotes;
    private Button btnCancel, btnSave;

    // Data
    private AppointmentDAO appointmentDAO;
    private PatientDAO patientDAO;
    private Appointment currentAppointment;
    private List<Patient> patientList;
    private int selectedPatientId = -1;
    private int appointmentId = -1;
    private boolean isEditMode = false;
    private Calendar selectedDate;
    private int selectedHour = 9;
    private int selectedMinute = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_appointment);

        // Get extras from intent
        selectedPatientId = getIntent().getIntExtra(Constants.EXTRA_PATIENT_ID, -1);
        appointmentId = getIntent().getIntExtra(Constants.EXTRA_APPOINTMENT_ID, -1);
        isEditMode = getIntent().getBooleanExtra(Constants.EXTRA_IS_EDIT_MODE, false);

        // Initialize DAOs
        appointmentDAO = new AppointmentDAO(this);
        patientDAO = new PatientDAO(this);

        // Initialize UI
        initializeViews();
        setupSpinners();
        setupClickListeners();

        // Load appointment data if editing
        if (isEditMode && appointmentId != -1) {
            loadAppointmentData();
        } else {
            // Set default values
            etAppointmentDate.setText(DateUtils.getCurrentDate());
            etAppointmentTime.setText("09:00 AM");
            spinnerStatus.setText(Constants.STATUS_SCHEDULED, false);
        }
    }

    private void initializeViews() {
        btnBack = findViewById(R.id.btnBack);
        tvTitle = findViewById(R.id.tvTitle);

        spinnerPatient = findViewById(R.id.spinnerPatient);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        etAppointmentDate = findViewById(R.id.etAppointmentDate);
        etAppointmentTime = findViewById(R.id.etAppointmentTime);
        etReason = findViewById(R.id.etReason);
        etNotes = findViewById(R.id.etNotes);

        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        // Update title
        if (isEditMode) {
            tvTitle.setText("Edit Appointment");
        } else {
            tvTitle.setText("New Appointment");
        }
    }

    private void setupSpinners() {
        // Load patients
        loadPatients();

        // Status Spinner
        String[] statuses = {
                "Scheduled",
                "In Progress",
                "Completed",
                "Cancelled"
        };
        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                statuses
        );
        spinnerStatus.setAdapter(statusAdapter);
    }

    private void loadPatients() {
        try {
            patientDAO.open();
            patientList = patientDAO.getAllPatients();

            List<String> patientNames = new ArrayList<>();
            for (Patient patient : patientList) {
                patientNames.add(patient.getFullName());
            }

            ArrayAdapter<String> patientAdapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_dropdown_item_1line,
                    patientNames
            );
            spinnerPatient.setAdapter(patientAdapter);

            // If patient ID was passed, select it
            if (selectedPatientId != -1) {
                for (int i = 0; i < patientList.size(); i++) {
                    if (patientList.get(i).getId() == selectedPatientId) {
                        spinnerPatient.setText(patientList.get(i).getFullName(), false);
                        break;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            patientDAO.close();
        }
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    saveAppointment();
                }
            }
        });

        etAppointmentDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        etAppointmentTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePicker();
            }
        });

        spinnerPatient.setOnItemClickListener((parent, view, position, id) -> {
            selectedPatientId = patientList.get(position).getId();
        });
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        selectedDate = Calendar.getInstance();
                        selectedDate.set(year, month, dayOfMonth);

                        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT, Locale.getDefault());
                        String dateString = sdf.format(selectedDate.getTime());
                        etAppointmentDate.setText(dateString);
                    }
                },
                year, month, day
        );

        // Set min date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void showTimePicker() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        selectedHour = hourOfDay;
                        selectedMinute = minute;

                        // Format time as 12-hour with AM/PM
                        String amPm = hourOfDay >= 12 ? "PM" : "AM";
                        int displayHour = hourOfDay % 12;
                        if (displayHour == 0) displayHour = 12;

                        String timeString = String.format(Locale.getDefault(),
                                "%02d:%02d %s", displayHour, minute, amPm);
                        etAppointmentTime.setText(timeString);
                    }
                },
                selectedHour, selectedMinute, false
        );

        timePickerDialog.show();
    }

    private void loadAppointmentData() {
        try {
            appointmentDAO.open();
            currentAppointment = appointmentDAO.getAppointmentById(appointmentId);

            if (currentAppointment != null) {
                // Set patient
                selectedPatientId = currentAppointment.getPatientId();
                loadPatients();

                // Set other fields
                etAppointmentDate.setText(currentAppointment.getAppointmentDate());
                etAppointmentTime.setText(currentAppointment.getAppointmentTime());
                etReason.setText(currentAppointment.getReason());
                etNotes.setText(currentAppointment.getNotes());

                // Set status
                String status = currentAppointment.getStatusDisplayName();
                spinnerStatus.setText(status, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading appointment", Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    private boolean validateInputs() {
        String selectedPatient = spinnerPatient.getText().toString().trim();
        String appointmentDate = etAppointmentDate.getText().toString().trim();
        String appointmentTime = etAppointmentTime.getText().toString().trim();
        String reason = etReason.getText().toString().trim();

        // Validate patient selection
        if (selectedPatient.isEmpty() || selectedPatientId == -1) {
            spinnerPatient.setError("Please select a patient");
            spinnerPatient.requestFocus();
            return false;
        }

        // Validate date
        if (appointmentDate.isEmpty()) {
            etAppointmentDate.setError(getString(R.string.required_field));
            etAppointmentDate.requestFocus();
            return false;
        }

        // Validate time
        if (appointmentTime.isEmpty()) {
            etAppointmentTime.setError(getString(R.string.required_field));
            etAppointmentTime.requestFocus();
            return false;
        }

        // Validate reason
        if (reason.isEmpty()) {
            etReason.setError(getString(R.string.required_field));
            etReason.requestFocus();
            return false;
        }

        return true;
    }

    private void saveAppointment() {
        try {
            // Create or update appointment object
            if (currentAppointment == null) {
                currentAppointment = new Appointment();
            }

            currentAppointment.setPatientId(selectedPatientId);
            currentAppointment.setAppointmentDate(etAppointmentDate.getText().toString().trim());
            currentAppointment.setAppointmentTime(etAppointmentTime.getText().toString().trim());
            currentAppointment.setReason(etReason.getText().toString().trim());
            currentAppointment.setNotes(etNotes.getText().toString().trim());

            // Convert status display name to database value
            String statusDisplay = spinnerStatus.getText().toString();
            String status = Constants.STATUS_SCHEDULED;
            if (statusDisplay.equals("In Progress")) {
                status = Constants.STATUS_IN_PROGRESS;
            } else if (statusDisplay.equals("Completed")) {
                status = Constants.STATUS_COMPLETED;
            } else if (statusDisplay.equals("Cancelled")) {
                status = Constants.STATUS_CANCELLED;
            }
            currentAppointment.setStatus(status);

            appointmentDAO.open();

            if (isEditMode && appointmentId != -1) {
                // Update existing appointment
                currentAppointment.setId(appointmentId);
                int result = appointmentDAO.updateAppointment(currentAppointment);

                if (result > 0) {
                    Toast.makeText(this, "Appointment updated successfully", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            } else {
                // Insert new appointment
                long id = appointmentDAO.insertAppointment(currentAppointment);

                if (id > 0) {
                    Toast.makeText(this, R.string.appointment_added, Toast.LENGTH_SHORT).show();

                    // Schedule notification (1 hour before)
                    scheduleNotification(currentAppointment);

                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    private void scheduleNotification(Appointment appointment) {
        try {
            // Parse date and time
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault());
            String dateTimeString = appointment.getAppointmentDate() + " " + appointment.getAppointmentTime();
            Date appointmentDateTime = sdf.parse(dateTimeString);

            if (appointmentDateTime != null) {
                // Schedule notification 1 hour before
                long notificationTime = appointmentDateTime.getTime() - (60 * 60 * 1000);

                if (notificationTime > System.currentTimeMillis()) {
                    // Create notification intent
                    Intent intent = new Intent(this, AppointmentNotificationReceiver.class);
                    intent.putExtra("appointment_id", appointment.getId());
                    intent.putExtra("patient_name", appointment.getPatientName());
                    intent.putExtra("appointment_time", appointment.getAppointmentTime());

                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this,
                            (int) appointment.getId(),
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );

                    AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    if (alarmManager != null) {
                        alarmManager.setExactAndAllowWhileIdle(
                                AlarmManager.RTC_WAKEUP,
                                notificationTime,
                                pendingIntent
                        );

                        Toast.makeText(this, "Reminder set for 1 hour before appointment", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (appointmentDAO != null) {
            appointmentDAO.close();
        }
        if (patientDAO != null) {
            patientDAO.close();
        }
    }
}