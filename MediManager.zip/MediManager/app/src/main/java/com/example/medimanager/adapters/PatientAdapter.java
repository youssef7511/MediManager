package com.example.medimanager.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.models.Patient;

import java.util.List;
import java.util.Random;

public class PatientAdapter extends RecyclerView.Adapter<PatientAdapter.PatientViewHolder> {

    private Context context;
    private List<Patient> patientList;
    private OnItemClickListener listener;

    // Interface for click listeners
    public interface OnItemClickListener {
        void onItemClick(Patient patient);
        void onEditClick(Patient patient);
        void onDeleteClick(Patient patient);
    }

    public PatientAdapter(Context context, List<Patient> patientList) {
        this.context = context;
        this.patientList = patientList;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_patient, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patientList.get(position);

        // Set patient name
        holder.tvPatientName.setText(patient.getFullName());

        // Set avatar initials
        holder.tvAvatar.setText(patient.getInitials());

        // Set random avatar color
        holder.tvAvatar.setBackgroundColor(getRandomAvatarColor());

        // Set age
        holder.tvAge.setText(patient.getAgeString());

        // Set gender
        holder.tvGender.setText(patient.getGender() != null ? patient.getGender() : "");

        // Set blood group
        String bloodGroup = patient.getBloodGroup();
        if (bloodGroup != null && !bloodGroup.isEmpty()) {
            holder.tvBloodGroup.setText("Blood: " + bloodGroup);
        } else {
            holder.tvBloodGroup.setText("Blood: N/A");
        }

        // Set last visit
        String lastVisit = patient.getLastVisit();
        if (lastVisit != null && !lastVisit.isEmpty()) {
            holder.tvLastVisit.setText("Last visit: " + lastVisit);
        } else {
            holder.tvLastVisit.setText("Last visit: N/A");
        }

        // Set click listeners
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(patient);
                }
            }
        });

        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onEditClick(patient);
                }
            }
        });

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onDeleteClick(patient);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return patientList != null ? patientList.size() : 0;
    }

    public void updateList(List<Patient> newList) {
        this.patientList = newList;
        notifyDataSetChanged();
    }

    public void removeItem(int position) {
        patientList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, patientList.size());
    }

    private int getRandomAvatarColor() {
        int[] colors = {
                Color.parseColor("#64B5F6"), // Blue
                Color.parseColor("#81C784"), // Green
                Color.parseColor("#FFB74D"), // Orange
                Color.parseColor("#BA68C8"), // Purple
                Color.parseColor("#F06292")  // Pink
        };

        Random random = new Random();
        return colors[random.nextInt(colors.length)];
    }

    public static class PatientViewHolder extends RecyclerView.ViewHolder {
        TextView tvAvatar, tvPatientName, tvAge, tvGender, tvBloodGroup, tvLastVisit;
        ImageButton btnEdit, btnDelete;

        public PatientViewHolder(@NonNull View itemView) {
            super(itemView);

            tvAvatar = itemView.findViewById(R.id.tvAvatar);
            tvPatientName = itemView.findViewById(R.id.tvPatientName);
            tvAge = itemView.findViewById(R.id.tvAge);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvBloodGroup = itemView.findViewById(R.id.tvBloodGroup);
            tvLastVisit = itemView.findViewById(R.id.tvLastVisit);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}