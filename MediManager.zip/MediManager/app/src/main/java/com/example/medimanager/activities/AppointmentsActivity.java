package com.example.medimanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medimanager.R;
import com.example.medimanager.adapters.AppointmentAdapter;
import com.example.medimanager.database.AppointmentDAO;
import com.example.medimanager.models.Appointment;
import com.example.medimanager.utils.Constants;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class AppointmentsActivity extends AppCompatActivity {

    // UI Components
    private ChipGroup chipGroupFilter;
    private Chip chipAll, chipScheduled, chipInProgress, chipCompleted;
    private RecyclerView rvAppointments;
    private TextView tvEmptyState;
    private FloatingActionButton fabAddAppointment;

    // Data
    private AppointmentDAO appointmentDAO;
    private AppointmentAdapter appointmentAdapter;
    private List<Appointment> appointmentList;
    private List<Appointment> filteredList;
    private String currentFilter = "all";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments);

        // Initialize DAO
        appointmentDAO = new AppointmentDAO(this);

        // Initialize UI
        initializeViews();
        setupRecyclerView();
        setupFilterChips();
        setupClickListeners();

        // Load data
        loadAppointments();
    }

    private void initializeViews() {
        chipGroupFilter = findViewById(R.id.chipGroupFilter);
        chipAll = findViewById(R.id.chipAll);
        chipScheduled = findViewById(R.id.chipScheduled);
        chipInProgress = findViewById(R.id.chipInProgress);
        chipCompleted = findViewById(R.id.chipCompleted);
        rvAppointments = findViewById(R.id.rvAppointments);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        fabAddAppointment = findViewById(R.id.fabAddAppointment);
    }

    private void setupRecyclerView() {
        appointmentList = new ArrayList<>();
        filteredList = new ArrayList<>();

        appointmentAdapter = new AppointmentAdapter(this, filteredList);
        rvAppointments.setLayoutManager(new LinearLayoutManager(this));
        rvAppointments.setAdapter(appointmentAdapter);

        // Set click listeners
        appointmentAdapter.setOnItemClickListener(new AppointmentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Appointment appointment) {
                // Open patient details
                Intent intent = new Intent(AppointmentsActivity.this, PatientDetailsActivity.class);
                intent.putExtra(Constants.EXTRA_PATIENT_ID, appointment.getPatientId());
                startActivity(intent);
            }

            @Override
            public void onStatusClick(Appointment appointment) {
                updateAppointmentStatus(appointment);
            }
        });
    }

    private void setupFilterChips() {
        chipGroupFilter.setOnCheckedStateChangeListener(new ChipGroup.OnCheckedStateChangeListener() {
            @Override
            public void onCheckedChanged(ChipGroup group, List<Integer> checkedIds) {
                if (checkedIds.isEmpty()) {
                    chipAll.setChecked(true);
                    return;
                }

                int checkedId = checkedIds.get(0);
                if (checkedId == R.id.chipAll) {
                    currentFilter = "all";
                } else if (checkedId == R.id.chipScheduled) {
                    currentFilter = Constants.STATUS_SCHEDULED;
                } else if (checkedId == R.id.chipInProgress) {
                    currentFilter = Constants.STATUS_IN_PROGRESS;
                } else if (checkedId == R.id.chipCompleted) {
                    currentFilter = Constants.STATUS_COMPLETED;
                }

                filterAppointments();
            }
        });
    }

    private void setupClickListeners() {
        fabAddAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AppointmentsActivity.this, AddAppointmentActivity.class);
                startActivityForResult(intent, Constants.REQUEST_ADD_APPOINTMENT);
            }
        });
    }

    private void loadAppointments() {
        try {
            appointmentDAO.open();
            appointmentList = appointmentDAO.getAllAppointments();
            filterAppointments();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading appointments", Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    private void filterAppointments() {
        filteredList.clear();

        if (currentFilter.equals("all")) {
            filteredList.addAll(appointmentList);
        } else {
            for (Appointment appointment : appointmentList) {
                if (currentFilter.equals(appointment.getStatus())) {
                    filteredList.add(appointment);
                }
            }
        }

        appointmentAdapter.notifyDataSetChanged();
        updateUI();
    }

    private void updateUI() {
        if (filteredList.isEmpty()) {
            rvAppointments.setVisibility(View.GONE);
            tvEmptyState.setVisibility(View.VISIBLE);
            tvEmptyState.setText("No appointments found");
        } else {
            rvAppointments.setVisibility(View.VISIBLE);
            tvEmptyState.setVisibility(View.GONE);
        }
    }

    private void updateAppointmentStatus(Appointment appointment) {
        try {
            appointmentDAO.open();

            String newStatus;
            if (appointment.isScheduled()) {
                newStatus = Constants.STATUS_IN_PROGRESS;
            } else if (appointment.isInProgress()) {
                newStatus = Constants.STATUS_COMPLETED;
            } else {
                newStatus = Constants.STATUS_SCHEDULED;
            }

            int result = appointmentDAO.updateAppointmentStatus(appointment.getId(), newStatus);

            if (result > 0) {
                appointment.setStatus(newStatus);
                appointmentAdapter.notifyDataSetChanged();
                Toast.makeText(this, "Status updated", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error updating status", Toast.LENGTH_SHORT).show();
        } finally {
            appointmentDAO.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            loadAppointments();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadAppointments();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (appointmentDAO != null) {
            appointmentDAO.close();
        }
    }
}