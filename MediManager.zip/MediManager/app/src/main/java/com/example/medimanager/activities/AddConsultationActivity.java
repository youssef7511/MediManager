package com.example.medimanager.activities;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medimanager.R;
import com.example.medimanager.database.ConsultationDAO;
import com.example.medimanager.database.PatientDAO;
import com.example.medimanager.models.Consultation;
import com.example.medimanager.models.Patient;
import com.example.medimanager.utils.Constants;
import com.example.medimanager.utils.DateUtils;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddConsultationActivity extends AppCompatActivity {

    // UI Components
    private ImageButton btnBack;
    private TextView tvTitle, tvPatientName;
    private TextInputEditText etConsultationDate, etDiagnosis, etTreatment, etPrescription, etNotes;
    private Button btnCancel, btnSave;

    // Data
    private ConsultationDAO consultationDAO;
    private PatientDAO patientDAO;
    private Consultation currentConsultation;
    private int patientId;
    private int consultationId = -1;
    private boolean isEditMode = false;
    private Calendar selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_consultation);

        // Get extras from intent
        patientId = getIntent().getIntExtra(Constants.EXTRA_PATIENT_ID, -1);
        consultationId = getIntent().getIntExtra(Constants.EXTRA_CONSULTATION_ID, -1);
        isEditMode = getIntent().getBooleanExtra(Constants.EXTRA_IS_EDIT_MODE, false);

        if (patientId == -1) {
            Toast.makeText(this, "Error: Patient not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize DAOs
        consultationDAO = new ConsultationDAO(this);
        patientDAO = new PatientDAO(this);

        // Initialize UI
        initializeViews();
        setupClickListeners();
        loadPatientName();

        // Load consultation data if editing
        if (isEditMode && consultationId != -1) {
            loadConsultationData();
        } else {
            // Set current date by default
            etConsultationDate.setText(DateUtils.getCurrentDate());
        }
    }

    private void initializeViews() {
        btnBack = findViewById(R.id.btnBack);
        tvTitle = findViewById(R.id.tvTitle);
        tvPatientName = findViewById(R.id.tvPatientName);

        etConsultationDate = findViewById(R.id.etConsultationDate);
        etDiagnosis = findViewById(R.id.etDiagnosis);
        etTreatment = findViewById(R.id.etTreatment);
        etPrescription = findViewById(R.id.etPrescription);
        etNotes = findViewById(R.id.etNotes);

        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        // Update title
        if (isEditMode) {
            tvTitle.setText("Edit Consultation");
        } else {
            tvTitle.setText(R.string.add_consultation);
        }
    }

    private void setupClickListeners() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    saveConsultation();
                }
            }
        });

        etConsultationDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });
    }

    private void loadPatientName() {
        try {
            patientDAO.open();
            Patient patient = patientDAO.getPatientById(patientId);
            if (patient != null) {
                tvPatientName.setText("Patient: " + patient.getFullName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            patientDAO.close();
        }
    }

    private void loadConsultationData() {
        try {
            consultationDAO.open();
            currentConsultation = consultationDAO.getConsultationById(consultationId);

            if (currentConsultation != null) {
                etConsultationDate.setText(currentConsultation.getConsultationDate());
                etDiagnosis.setText(currentConsultation.getDiagnosis());
                etTreatment.setText(currentConsultation.getTreatment());
                etPrescription.setText(currentConsultation.getPrescription());
                etNotes.setText(currentConsultation.getNotes());
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading consultation", Toast.LENGTH_SHORT).show();
        } finally {
            consultationDAO.close();
        }
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();

        // If editing and date exists, use it
        if (isEditMode && currentConsultation != null && currentConsultation.getConsultationDate() != null) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT, Locale.getDefault());
                calendar.setTime(sdf.parse(currentConsultation.getConsultationDate()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        selectedDate = Calendar.getInstance();
                        selectedDate.set(year, month, dayOfMonth);

                        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT, Locale.getDefault());
                        String dateString = sdf.format(selectedDate.getTime());
                        etConsultationDate.setText(dateString);
                    }
                },
                year, month, day
        );

        // Set max date to today
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private boolean validateInputs() {
        String consultationDate = etConsultationDate.getText().toString().trim();
        String diagnosis = etDiagnosis.getText().toString().trim();

        // Validate consultation date
        if (consultationDate.isEmpty()) {
            etConsultationDate.setError(getString(R.string.required_field));
            etConsultationDate.requestFocus();
            return false;
        }

        // Validate diagnosis
        if (diagnosis.isEmpty()) {
            etDiagnosis.setError(getString(R.string.required_field));
            etDiagnosis.requestFocus();
            return false;
        }

        return true;
    }

    private void saveConsultation() {
        try {
            // Create or update consultation object
            if (currentConsultation == null) {
                currentConsultation = new Consultation();
            }

            currentConsultation.setPatientId(patientId);
            currentConsultation.setConsultationDate(etConsultationDate.getText().toString().trim());
            currentConsultation.setDiagnosis(etDiagnosis.getText().toString().trim());
            currentConsultation.setTreatment(etTreatment.getText().toString().trim());
            currentConsultation.setPrescription(etPrescription.getText().toString().trim());
            currentConsultation.setNotes(etNotes.getText().toString().trim());

            consultationDAO.open();

            if (isEditMode && consultationId != -1) {
                // Update existing consultation
                currentConsultation.setId(consultationId);
                int result = consultationDAO.updateConsultation(currentConsultation);

                if (result > 0) {
                    Toast.makeText(this, R.string.consultation_updated, Toast.LENGTH_SHORT).show();

                    // Update patient's last visit date
                    updatePatientLastVisit(currentConsultation.getConsultationDate());

                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            } else {
                // Insert new consultation
                long id = consultationDAO.insertConsultation(currentConsultation);

                if (id > 0) {
                    Toast.makeText(this, R.string.consultation_added, Toast.LENGTH_SHORT).show();

                    // Update patient's last visit date
                    updatePatientLastVisit(currentConsultation.getConsultationDate());

                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, R.string.error_occurred, Toast.LENGTH_SHORT).show();
        } finally {
            consultationDAO.close();
        }
    }

    private void updatePatientLastVisit(String visitDate) {
        try {
            patientDAO.open();
            patientDAO.updateLastVisit(patientId, visitDate);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            patientDAO.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (consultationDAO != null) {
            consultationDAO.close();
        }
        if (patientDAO != null) {
            patientDAO.close();
        }
    }
}