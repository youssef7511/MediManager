package com.example.medimanager.database;

public class ConsultationDAO {
}
